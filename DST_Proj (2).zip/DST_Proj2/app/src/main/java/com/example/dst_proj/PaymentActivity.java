package com.example.dst_proj;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class PaymentActivity extends AppCompatActivity {

    private EditText paymentAmount;
    private Spinner paymentOptionsSpinner;
    private Button payButton, viewReceiptsButton;
    private DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);

        // Initialize Firebase Database reference
        databaseReference = FirebaseDatabase.getInstance().getReference("receipts");

        paymentAmount = findViewById(R.id.paymentAmount);
        paymentOptionsSpinner = findViewById(R.id.paymentOptionsSpinner);
        payButton = findViewById(R.id.payButton);
        viewReceiptsButton = findViewById(R.id.viewReceiptsButton);

        payButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                processPayment();
            }
        });

        viewReceiptsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(PaymentActivity.this, ReceiptsActivity.class);
                startActivity(intent);
            }
        });
    }

    private void processPayment() {
        String amountStr = paymentAmount.getText().toString();
        String description = paymentOptionsSpinner.getSelectedItem().toString();
        if (!amountStr.isEmpty()) {
            double amount = Double.parseDouble(amountStr);
            postPaymentToFirebase(description, amount);
            Intent resultIntent = new Intent();
            resultIntent.putExtra("amount", amount);
            resultIntent.putExtra("description", description);
            setResult(RESULT_OK, resultIntent);
            finish();
        } else {
            Toast.makeText(PaymentActivity.this, "Enter an amount to pay.", Toast.LENGTH_SHORT).show();
        }
    }

    private void postPaymentToFirebase(String description, double amount) {
        String key = databaseReference.push().getKey();
        Receipt receipt = new Receipt(description, amount);
        databaseReference.child(key).setValue(receipt)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        Toast.makeText(PaymentActivity.this, "Payment posted to Firebase", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(PaymentActivity.this, "Failed to post payment", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    public static class Receipt {
        public String description;
        public double amount;

        public Receipt() {
            // Default constructor required for calls to DataSnapshot.getValue(Receipt.class)
        }

        public Receipt(String description, double amount) {
            this.description = description;
            this.amount = amount;
        }
    }
}
