package com.example.dst_proj;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
public class GoogleWalletActivity extends Activity {
    private EditText googleWalletAmountField;
    private Button depositButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_google_wallet);

        googleWalletAmountField = findViewById(R.id.googleWalletAmount);
        depositButton = findViewById(R.id.depositButton);

        depositButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String amountStr = googleWalletAmountField.getText().toString();
                if (!amountStr.isEmpty()) {
                    double amount = Double.parseDouble(amountStr);
                    if (amount > 0) {
                        Intent resultIntent = new Intent();
                        resultIntent.putExtra("depositAmount", amount);
                        setResult(RESULT_OK, resultIntent);
                        finish();
                    } else {
                        Toast.makeText(GoogleWalletActivity.this, "Enter amount >Ksh10.", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(GoogleWalletActivity.this, "Enter amount.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}