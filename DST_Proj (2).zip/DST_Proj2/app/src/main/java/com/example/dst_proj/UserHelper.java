package com.example.dst_proj;

public class UserHelper {
    public String fullName, username, email, phoneNumber;

    public UserHelper() {
        // Default constructor required for calls to DataSnapshot.getValue(UserHelper.class)
    }

    public UserHelper(String fullName, String username, String email, String phoneNumber) {
        this.fullName = fullName;
        this.username = username;
        this.email = email;
        this.phoneNumber = phoneNumber;
    }
}
