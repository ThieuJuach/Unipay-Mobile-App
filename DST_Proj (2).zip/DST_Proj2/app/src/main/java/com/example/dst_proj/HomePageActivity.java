package com.example.dst_proj;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class HomePageActivity extends AppCompatActivity {

    private TextView currentBalanceTextView;
    private EditText depositAmountField, transferAmountField, transferEmailField;
    private Button depositMpesaButton, depositWalletButton, transferButton, payBuyButton;

    private double currentBalance = 0.00;
    private DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);

        currentBalanceTextView = findViewById(R.id.currentBalance);
        depositAmountField = findViewById(R.id.depositAmount);
        transferAmountField = findViewById(R.id.transferAmount);
        transferEmailField = findViewById(R.id.transferEmail);
        depositMpesaButton = findViewById(R.id.depositMpesaButton);
        depositWalletButton = findViewById(R.id.depositWalletButton);
        transferButton = findViewById(R.id.transferButton);
        payBuyButton = findViewById(R.id.payBuyButton);

        databaseReference = FirebaseDatabase.getInstance().getReference("transactions");

        updateCurrentBalance();

        depositMpesaButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String depositAmountStr = depositAmountField.getText().toString();
                if (!depositAmountStr.isEmpty()) {
                    double depositAmount = Double.parseDouble(depositAmountStr);
                    deposit(depositAmount);
                } else {
                    Toast.makeText(HomePageActivity.this, "Enter an amount to deposit.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        depositWalletButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomePageActivity.this, GoogleWalletActivity.class);
                startActivityForResult(intent, 1);  // Request code 1 for deposit from wallet
            }
        });

        transferButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String transferAmountStr = transferAmountField.getText().toString();
                String transferEmail = transferEmailField.getText().toString();

                if (!transferAmountStr.isEmpty() && !transferEmail.isEmpty()) {
                    double transferAmount = Double.parseDouble(transferAmountStr);
                    if (validateEmail(transferEmail)) {
                        if (transferAmount > 10) {
                            transfer(transferAmount, transferEmail);
                        } else {
                            Toast.makeText(HomePageActivity.this, "Transfer amount must be more than 10.", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(HomePageActivity.this, "Not a USIU email.", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(HomePageActivity.this, "Enter both amount and student email.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        payBuyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomePageActivity.this, PaymentActivity.class);
                startActivityForResult(intent, 2);  // Request code 2 for payments
            }
        });
    }

    private void updateCurrentBalance() {
        currentBalanceTextView.setText("CURRENT BALANCE: Ksh" + String.format("%.2f", currentBalance));
    }

    private void deposit(double amount) {
        currentBalance += amount;
        updateCurrentBalance();
        saveTransaction(amount, "Deposit");
        Toast.makeText(this, "Deposited Ksh" + amount, Toast.LENGTH_SHORT).show();
    }

    private boolean validateEmail(String email) {
        return email.endsWith("@usiu.ac.ke");
    }

    private void transfer(double amount, String email) {
        if (currentBalance >= amount) {
            currentBalance -= amount;
            updateCurrentBalance();
            saveTransaction(amount, "Transfer to " + email);
            Toast.makeText(this, "Transferred Ksh" + amount + " to " + email, Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Insufficient balance.", Toast.LENGTH_SHORT).show();
        }
    }

    private void deductAmount(double amount, String description) {
        if (currentBalance >= amount) {
            currentBalance -= amount;
            updateCurrentBalance();
            saveTransaction(amount, description);
            Toast.makeText(this, "Paid Ksh" + amount + " for " + description, Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Insufficient balance.", Toast.LENGTH_SHORT).show();
        }
    }

    private void saveTransaction(double amount, String description) {
        String transactionId = databaseReference.push().getKey();
        Transaction transaction = new Transaction(amount, description);
        databaseReference.child(transactionId).setValue(transaction);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == RESULT_OK) {
            double depositAmount = data.getDoubleExtra("depositAmount", 0.00);
            deposit(depositAmount);
        } else if (requestCode == 2 && resultCode == RESULT_OK) {
            double amount = data.getDoubleExtra("amount", 0.00);
            String description = data.getStringExtra("description");
            deductAmount(amount, description);
        }
    }
}
